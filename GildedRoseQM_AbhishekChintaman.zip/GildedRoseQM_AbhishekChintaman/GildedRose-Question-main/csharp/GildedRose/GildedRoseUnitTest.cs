using System.Collections.Generic;
using NUnit.Framework;

namespace GildedRose
{
    public class GildedRoseUnitTest
    {
        [SetUp]
        public void Setup()
        {
        }

        IList<Item> items = new List<Item>
            {
                new Item { Name = Utility.AGED_BRIE,    SellIn = 2,  Quality = 0  },
                new Item { Name = Utility.BACK_STAGE,   SellIn = 15, Quality = 20 },
                new Item { Name = Utility.SULFURAS,     SellIn = 0,  Quality = 80 },

                new Item { Name = Utility.DEXTERITY,    SellIn = 10, Quality = 20 },
                new Item { Name = Utility.ELIXIR,       SellIn = 5,  Quality = 7  },

                new Item { Name = Utility.CONJURED,     SellIn = 3,  Quality = 6  }
            };

        private Item GetUpdatedItems(string name, int sellIn, int quality)
        {
            IList<Item> items = new List<Item> { new Item { Name = name, SellIn = sellIn, Quality = quality } };
            GildedRose app = new GildedRose() { Items = items };
            app.UpdateQuality();

            return items[0];
        }


        //// Test Cases for "Aged Brie":

        [Test]
        public void AgedBrie1_QualityIncreases()
        {
            Item item = GetUpdatedItems(Utility.AGED_BRIE, 15, 25);
            Assert.AreEqual(26, item.Quality);
        }

        [Test]
        public void AgedBrie2_QualityNeverMoreThan50()
        {
            Item item = GetUpdatedItems(Utility.AGED_BRIE, 15, Utility.MAX_QUALITY);
            Assert.AreEqual(Utility.MAX_QUALITY, item.Quality);
        }

        [Test]
        public void AgedBrie3_PassedSellIn_QualityNeverMoreThan50()
        {
            Item item = GetUpdatedItems(Utility.AGED_BRIE, 0, 49);
            Assert.AreEqual(Utility.MAX_QUALITY, item.Quality);
        }

        [Test]
        public void AgedBrie4_PassedSellIn_QualityIncreasesBy2()
        {
            Item item = GetUpdatedItems(Utility.AGED_BRIE, 0, 25);
            Assert.AreEqual(27, item.Quality);
        }

        //// Test Cases for "Backstage passes to a TAFKAL80ETC concert":

        [Test]
        public void BackstagePasses1_QualityIncreases()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 15, 25);
            Assert.AreEqual(26, item.Quality);
        }

        [Test]
        public void BackstagePasses2_10DaysOut_QualityIncreasesBy2()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 10, 25);
            Assert.AreEqual(27, item.Quality);
        }

        [Test]
        public void BackstagePasses3_10DaysOut_QualityNeverMoreThan50()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 10, 49);
            Assert.AreEqual(Utility.MAX_QUALITY, item.Quality);
        }

        [Test]
        public void BackstagePasses4_5DaysOut_QualityIncreasesBy3()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 5, 25);
            Assert.AreEqual(28, item.Quality);
        }
        [Test]
        public void BackstagePasses5_5DaysOut_QualityNeverMoreThan50()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 5, 48);
            Assert.AreEqual(Utility.MAX_QUALITY, item.Quality);
        }

        [Test]
        public void BackstagePasses6_PassedSellIn_QualityDropsTo0()
        {
            Item item = GetUpdatedItems(Utility.BACK_STAGE, 0, 25);
            Assert.AreEqual(0, item.Quality);
        }

        //// Test Cases for "Sulfuras, Hand of Ragnaros":

        [Test]
        public void Sulfuras1_QualityNeverDecreases()
        {
            Item item = GetUpdatedItems(Utility.SULFURAS, 15, 80);
            Assert.AreEqual(80, item.Quality);
        }

        [Test]
        public void Sulfuras2_PassedSellIn_QualityNeverDecreases()
        {
            Item item = GetUpdatedItems(Utility.SULFURAS, -1, 80);
            Assert.AreEqual(80, item.Quality);
        }

        ////// Test Cases for other item- "+5 Dexterity Vest":

        [Test]
        public void Dexterity1_SellInAndQualityCheck()
        {
            Item item = GetUpdatedItems(Utility.DEXTERITY, 15, 25);
            Assert.AreEqual(14, item.SellIn);
            Assert.AreEqual(24, item.Quality);
        }

        [Test]
        public void Dexterity2_QualityDegradesTwiceAsFast()
        {
            Item item = GetUpdatedItems(Utility.DEXTERITY, 0, 25);
            Assert.AreEqual(23, item.Quality);
        }

        [Test]
        public void Dexterity3_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.DEXTERITY, 15, 0);
            Assert.AreEqual(0, item.Quality);
        }

        [Test]
        public void Dexterity4_PassedSellIn_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.DEXTERITY, 0, 0);
            Assert.AreEqual(0, item.Quality);
        }

        [Test]
        public void Dexterity5_PassedSellIn_QualityNeverNegative2()
        {
            Item item = GetUpdatedItems(Utility.DEXTERITY, -1, 0);
            Assert.AreEqual(0, item.Quality);
        }

        ////// Test Cases for other item- "Elixir of the Mongoose":

        [Test]
        public void Elixir1_SellInAndQualityCheck()
        {
            Item item = GetUpdatedItems(Utility.ELIXIR, 15, 25);
            Assert.AreEqual(14, item.SellIn);
            Assert.AreEqual(24, item.Quality);
        }

        [Test]
        public void Elixir2_QualityDegradesTwiceAsFast()
        {
            Item item = GetUpdatedItems(Utility.ELIXIR, 0, 25);
            Assert.AreEqual(23, item.Quality);
        }

        [Test]
        public void Elixir3_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.ELIXIR, 15, 0);
            Assert.AreEqual(0, item.Quality);
        }

        [Test]
        public void Elixir4_PassedSellIn_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.ELIXIR, 0, 0);
            Assert.AreEqual(0, item.Quality);
        }

        [Test]
        public void Elixir5_PassedSellIn_QualityNeverNegative2()
        {
            Item item = GetUpdatedItems(Utility.ELIXIR, -1, 0);
            Assert.AreEqual(0, item.Quality);
        }

        //// Test Cases for New Requirements- "Conjured Mana Cake"

        [Test]
        public void Conjured1_QualityDegradesTwiceAsFast()
        {
            Item item = GetUpdatedItems(Utility.CONJURED, 15, 25);
            Assert.AreEqual(23, item.Quality);
        }

        [Test]
        public void Conjured2_PassedSellIn_QualityDegradesTwiceAsFast()
        {
            Item item = GetUpdatedItems(Utility.CONJURED, 0, 25);
            Assert.AreEqual(21, item.Quality);
        }

        [Test]
        public void Conjured3_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.CONJURED, 15, 0);
            Assert.AreEqual(0, item.Quality);
        }

        [Test]
        public void Conjured4_PassedSellIn_QualityNeverNegative()
        {
            Item item = GetUpdatedItems(Utility.CONJURED, 0, 0);
            Assert.AreEqual(0, item.Quality);
        }
    }
}