﻿using System;
using System.Collections.Generic;

namespace GildedRose
{
    public class GildedRose
    {
        public IList<Item> Items = new List<Item>();

        public GildedRose()
        {

        }

        public GildedRose(List<Item> items)
        {
            this.Items = items;
        }
        public void UpdateQuality()
        {
            for (var i = 0; i < Items.Count; i++)
            {
                Item item = Items[i];

                ManageOtherGoods(item);
                ManageAgedBrie(item);
                ManageBackStagePasses(item);
                ManageSulfuras(item);
                ManageConjured(item);
            }
        }

        public void ManageOtherGoods(Item item)
        {
            if (Utility.IsRegular(item))
            {
                item.SellIn--;
                item.Quality--;

                if (item.SellIn <= 0)
                    item.Quality--;

                if (item.Quality < 0)
                    item.Quality = 0;
            }
        }
        public void ManageAgedBrie(Item item)
        {
            if (Utility.IsAgedBrie(item))
            {
                item.SellIn--;
                item.Quality++;

                if (item.SellIn <= 0)
                    item.Quality++;

                if (item.Quality > Utility.MAX_QUALITY)
                    item.Quality = Utility.MAX_QUALITY;
            }
        }
        public void ManageBackStagePasses(Item item)
        {
            if (Utility.IsBackstagePasses(item))
            {
                item.SellIn--;
                item.Quality++;

                if (item.SellIn < Utility.BACK_STAGE_DAYS_1)
                    item.Quality++;

                if (item.SellIn < Utility.BACK_STAGE_DAYS_2)
                    item.Quality++;

                if (item.SellIn <= 0)
                    item.Quality = 0;

                if (item.Quality > Utility.MAX_QUALITY)
                    item.Quality = Utility.MAX_QUALITY;
            }
        }
        public void ManageSulfuras(Item item)
        {
            if (Utility.IsSulfurasHandOfRagnaros(item))
            {
                item.SellIn--;
            }
        }
        public void ManageConjured(Item item)
        {
            if (Utility.IsConjured(item))
            {
                item.SellIn--;
                item.Quality -= 2;

                if (item.SellIn <= 0)
                    item.Quality -= 2;

                if (item.Quality < 0)
                    item.Quality = 0;
            }
        }
    }
}
