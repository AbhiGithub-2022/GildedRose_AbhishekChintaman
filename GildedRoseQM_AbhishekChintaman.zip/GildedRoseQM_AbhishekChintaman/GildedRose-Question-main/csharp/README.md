# C# Gilded Rose

Requires .NET 6.0.

This can be run from the command line:

```bash
dotnet build
dotnet test
```
