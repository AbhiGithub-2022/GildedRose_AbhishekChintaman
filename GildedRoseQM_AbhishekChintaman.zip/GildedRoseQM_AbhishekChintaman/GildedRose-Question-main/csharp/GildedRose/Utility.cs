﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GildedRose
{
    public static class Utility
    {
        public const string DEXTERITY = "+5 Dexterity Vest";
        public const string AGED_BRIE = "Aged Brie";
        public const string ELIXIR = "Elixir of the Mongoose";
        public const string SULFURAS = "Sulfuras, Hand of Ragnaros";
        public const string BACK_STAGE = "Backstage passes to a TAFKAL80ETC concert";
        public const string CONJURED = "Conjured Mana Cake";

        public const int MAX_QUALITY = 50;
        public const int BACK_STAGE_DAYS_1 = 11;
        public const int BACK_STAGE_DAYS_2 = 6;

        public static bool IsAgedBrie(Item item)
        {
            return item.Name == Utility.AGED_BRIE;
        }
        public static bool IsBackstagePasses(Item item)
        {
            return item.Name == Utility.BACK_STAGE;
        }
        public static bool IsSulfurasHandOfRagnaros(Item item)
        {
            return item.Name == Utility.SULFURAS;
        }
        public static bool IsConjured(Item item)
        {
            return item.Name == Utility.CONJURED;
        }
        public static bool IsRegular(Item item)
        {
            return !(IsAgedBrie(item) || IsBackstagePasses(item) || IsSulfurasHandOfRagnaros(item) || IsConjured(item));
        }
    }
}
