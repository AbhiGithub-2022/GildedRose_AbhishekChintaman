﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GildedRose
{
    public class Program
    {
        //public IList<Item> Items;
        //public void Main(string[] args)
        //{
        //    System.Console.WriteLine("Gilded Rose Testing and Refectoring Kata!");

        //    var app = new GildedRose()
        //    {
        //        Items = new List<Item>
        //       {
        //        new Item { Name = Utility.AGED_BRIE,    SellIn = 2,  Quality = 0  },
        //        new Item { Name = Utility.BACK_STAGE,   SellIn = 15, Quality = 20 },
        //        new Item { Name = Utility.SULFURAS,     SellIn = 0,  Quality = 80 },

        //        new Item { Name = Utility.DEXTERITY,    SellIn = 10, Quality = 20 },
        //        new Item { Name = Utility.ELIXIR,       SellIn = 5,  Quality = 7  },

        //        new Item { Name = Utility.CONJURED,     SellIn = 3,  Quality = 6  }
        //       }
        //    };

        //    app.UpdateQuality();

        //    System.Console.ReadKey();

        //}
    }
}
